package com.steivy.allinone

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.content.res.ColorStateList
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.ViewOutlineProvider
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    // I-usab ang URL dinhi kung kinahanglan (ilabi na ang Dola)
    private val services = linkedMapOf(
        "Claude" to "https://claude.ai",
        "Gemini" to "https://gemini.google.com",
        "Dola" to "https://www.dola.com/chat/",
        "Flow" to "https://labs.google/fx/tools/flow"
    )
    private val videoServices = setOf("Dola", "Flow")
    private val limitWords = listOf(
        "reached your limit", "usage limit", "limit reached", "hit your limit", "rate limit",
        "too many requests", "daily limit", "out of credits", "no credits", "quota", "try again later"
    )
    private val ua: String by lazy { WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace(" Version/4.0", "") }
    private val aspects = arrayOf("9:16", "16:9", "1:1", "4:5")
    private val durLabels = Array(8) { "${3 + it} seconds" }

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var holder: FrameLayout
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var input: EditText
    private lateinit var autoBtn: TextView
    private lateinit var vidBtn: TextView
    private val tabBtns = linkedMapOf<String, TextView>()
    private val views = HashMap<String, WebView>()
    private val history = HashMap<String, MutableList<String>>()
    private var current = "Claude"
    private var auto = true
    private var lastSwitch = 0L
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val h = Handler(Looper.getMainLooper())

    private fun count() = prefs.getInt("count_$current", 1)
    private fun idx() = prefs.getInt("idx_$current", 0)
    private fun pname() = "${current.lowercase()}_${idx()}"
    private fun web() = views[pname()]
    private fun multi() = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
    private fun cookies(): CookieManager =
        if (multi()) ProfileStore.getInstance().getOrCreateProfile(pname()).cookieManager else CookieManager.getInstance()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private val BG = 0xFF0E0F14.toInt()
    private val SURF = 0xFF171923.toInt()
    private val SURF2 = 0xFF20232F.toInt()
    private val ACC = 0xFF7C5CFF.toInt()
    private val TXT = 0xFFF2F3F7.toInt()
    private val MUT = 0xFF8B90A0.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)

    private fun chip(t: String, icon: Int, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(TXT); gravity = Gravity.CENTER
        setPadding(dp(12), dp(9), dp(12), dp(9)); background = round(SURF2, 18)
        if (icon != 0) {
            setCompoundDrawablesRelativeWithIntrinsicBounds(icon, 0, 0, 0)
            compoundDrawablePadding = dp(6); compoundDrawableTintList = ColorStateList.valueOf(TXT)
        }
        layoutParams = lp(-2, -2).apply { setMargins(0, 0, dp(8), 0) }
        setOnClickListener { f() }
    }

    private fun iconBtn(res: Int, bg: Int, f: () -> Unit) = ImageView(this).apply {
        setImageResource(res); setColorFilter(TXT); setPadding(dp(11), dp(11), dp(11), dp(11))
        if (bg != 0) background = round(bg, 20)
        setOnClickListener { f() }
    }

    private fun styleAuto() {
        autoBtn.text = "Auto: " + if (auto) "ON" else "OFF"
        autoBtn.background = round(if (auto) 0xFF1F3D2E.toInt() else SURF2, 18)
        autoBtn.setTextColor(if (auto) 0xFF4ADE80.toInt() else MUT)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG; window.navigationBarColor = BG
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = getSharedPreferences("steivy", MODE_PRIVATE)
        current = prefs.getString("last", "Claude") ?: "Claude"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }

        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(10)) }
        head.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, lp(dp(40), dp(40)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        titles.addView(TextView(this).apply { text = "STEIVY"; setTextColor(TXT); textSize = 18f; letterSpacing = 0.14f; setTypeface(typeface, Typeface.BOLD) })
        titles.addView(TextView(this).apply { text = "ALL IN ONE"; setTextColor(ACC); textSize = 10f; letterSpacing = 0.3f })
        head.addView(titles, lp(0, -2, 1f))
        status = TextView(this).apply { setTextColor(TXT); textSize = 12f; setPadding(dp(12), dp(6), dp(12), dp(6)); background = round(SURF2, 14); setOnClickListener { pickAccount() } }
        head.addView(status)

        holder = FrameLayout(this).apply {
            setBackgroundColor(SURF); clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(18).toFloat()) }
            }
        }

        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = round(SURF2, 26); setPadding(dp(4), dp(4), dp(4), dp(4)) }
        bar.addView(iconBtn(R.drawable.ic_attach, 0) { attach() }, lp(dp(42), dp(42)))
        input = EditText(this).apply {
            background = null; maxLines = 4; textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setTextColor(TXT); setHintTextColor(MUT); setPadding(dp(8), 0, dp(8), 0)
        }
        bar.addView(input, lp(0, -2, 1f))
        bar.addView(iconBtn(R.drawable.ic_send, ACC) { sendFromBox() }, lp(dp(42), dp(42)))

        val opts = LinearLayout(this)
        opts.addView(chip("Download", R.drawable.ic_download) { downloadVideo() })
        vidBtn = chip("", R.drawable.ic_movie) { pickVideo() }
        opts.addView(vidBtn)
        opts.addView(chip("Recent", R.drawable.ic_history) { showRecent() })
        opts.addView(chip("Switch", R.drawable.ic_swap) { nextAccount(false) })
        opts.addView(chip("Reload", R.drawable.ic_reload) { web()?.reload() })
        opts.addView(chip("Browser", R.drawable.ic_open) {
            web()?.url?.let { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) } catch (e: Exception) { } }
        })
        opts.addView(chip("Account", R.drawable.ic_add) { addAccount() })
        autoBtn = chip("", 0) { auto = !auto; styleAuto() }
        opts.addView(autoBtn)
        val optsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; setPadding(dp(10), 0, dp(2), 0); addView(opts) }

        val tabs = LinearLayout(this).apply { background = round(SURF, 22); setPadding(dp(4), dp(4), dp(4), dp(4)) }
        services.keys.forEach { s ->
            val t = TextView(this).apply {
                text = s; textSize = 14f; gravity = Gravity.CENTER; setPadding(0, dp(11), 0, dp(11))
                setOnClickListener { current = s; show() }
            }
            tabBtns[s] = t
            tabs.addView(t, lp(0, -2, 1f))
        }

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(ACC); visibility = View.INVISIBLE
        }
        root.addView(head)
        root.addView(progress, lp(-1, dp(3)).apply { setMargins(dp(10), 0, dp(10), dp(6)) })
        root.addView(holder, lp(-1, 0, 1f).apply { setMargins(dp(10), 0, dp(10), dp(8)) })
        root.addView(bar, lp(-1, -2).apply { setMargins(dp(10), 0, dp(10), dp(8)) })
        root.addView(optsScroll, lp(-1, -2).apply { setMargins(0, 0, 0, dp(8)) })
        root.addView(tabs, lp(-1, -2).apply { setMargins(dp(10), 0, dp(10), dp(10)) })
        setContentView(root)
        styleAuto()
        show()
        h.postDelayed(watcher, 4000)
    }

    private fun refreshVid() {
        vidBtn.text = "${prefs.getString("aspect", "9:16")} · ${prefs.getInt("dur", 5)}s"
    }

    private fun show() {
        prefs.edit().putString("last", current).apply()
        val key = pname()
        views.values.forEach { it.visibility = View.GONE }
        val w = views.getOrPut(key) {
            makeWeb(key).also { holder.addView(it, FrameLayout.LayoutParams(-1, -1)); it.loadUrl(services[current]!!) }
        }
        w.visibility = View.VISIBLE
        status.text = "$current · Account ${idx() + 1}/${count()}"
        tabBtns.forEach { (k, t) ->
            val on = k == current
            t.background = if (on) round(ACC, 18) else null
            t.setTextColor(if (on) 0xFFFFFFFF.toInt() else MUT)
            t.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
        }
        input.hint = "Isulat para sa $current…"
        refreshVid()
    }

    private fun makeWeb(key: String): WebView {
        val w = WebView(this)
        if (multi()) {
            ProfileStore.getInstance().getOrCreateProfile(key)
            WebViewCompat.setProfile(w, key)
        }
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.userAgentString = ua
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.settings.javaScriptCanOpenWindowsAutomatically = true
        w.settings.databaseEnabled = true
        w.settings.setSupportMultipleWindows(false)
        cookies().setAcceptThirdPartyCookies(w, true)
        w.addJavascriptInterface(Bridge(), "Steivy")
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                val url = req.url.toString()
                if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("about:") ||
                    url.startsWith("blob:") || url.startsWith("data:") || url.startsWith("javascript:")) return false
                try {
                    if (url.startsWith("intent:")) {
                        val i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                        val fb = i.getStringExtra("browser_fallback_url")
                        if (fb != null && fb.startsWith("http")) { v.loadUrl(fb); return true }
                        i.addCategory(Intent.CATEGORY_BROWSABLE); i.component = null; i.selector = null
                        startActivity(i)
                    } else {
                        startActivity(Intent(Intent.ACTION_VIEW, req.url))
                    }
                } catch (e: Exception) { toast("Dili ma-abli ang link: ${e.message}") }
                return true
            }
            override fun onReceivedError(v: WebView, req: WebResourceRequest, err: WebResourceError) {
                if (req.isForMainFrame) toast("Error: ${err.description}")
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView?, p: Int) {
                if (v === web()) { progress.progress = p; progress.visibility = if (p in 1..99) View.VISIBLE else View.INVISIBLE }
            }
            override fun onShowFileChooser(v: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                startActivityForResult(Intent.createChooser(i, "Pili og file"), 77)
                return true
            }
        }
        w.setDownloadListener { url, _, _, _, _ ->
            if (url.startsWith("http")) downloadUrl(url) else toast("Gamita ang ⬇ Download button")
        }
        return w
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        if (rc == 77) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            fileCb = null
        } else super.onActivityResult(rc, res, data)
    }

    inner class Bridge {
        @JavascriptInterface fun msg(s: String) { runOnUiThread { toast(s) } }
        @JavascriptInterface fun download(url: String) { runOnUiThread { downloadUrl(url) } }
        @JavascriptInterface fun saveVideo(data: String) { Thread { saveData(data) }.start() }
    }

    private fun downloadUrl(url: String) {
        try {
            val req = DownloadManager.Request(Uri.parse(url))
                .addRequestHeader("Cookie", cookies().getCookie(url) ?: "")
                .addRequestHeader("User-Agent", ua)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, null, null))
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Nag-download… tan-awa ang notification")
        } catch (e: Exception) { toast("Dili ma-download: ${e.message}") }
    }

    private fun saveData(data: String) {
        try {
            val mime = data.substringAfter("data:").substringBefore(";").ifEmpty { "video/mp4" }
            val ext = mime.substringAfter("/")
            val bytes = Base64.decode(data.substringAfter(","), Base64.DEFAULT)
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "steivy_${System.currentTimeMillis()}.$ext")
                put(MediaStore.Video.Media.MIME_TYPE, mime)
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Steivy")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
            runOnUiThread { toast("Na-save sa Movies/Steivy ✔") }
        } catch (e: Exception) { runOnUiThread { toast("Dili ma-save: ${e.message}") } }
    }

    private fun downloadVideo() { web()?.evaluateJavascript("($DL_JS)()", null) }

    private fun attach() {
        web()?.evaluateJavascript("(function(){var i=document.querySelector('input[type=file]');if(i){i.click();return 'ok'}return 'none'})()") { r ->
            if (r != null && r.contains("none")) toast("I-tap ang attach/＋ button sa website; mo-abli ang file picker")
        }
    }

    private fun pickVideo() {
        AlertDialog.Builder(this).setTitle("Size").setItems(aspects) { _, i ->
            prefs.edit().putString("aspect", aspects[i]).apply()
            AlertDialog.Builder(this).setTitle("Duration").setItems(durLabels) { _, j ->
                prefs.edit().putInt("dur", 3 + j).apply(); refreshVid()
            }.show()
        }.show()
    }

    private fun sendFromBox() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        var out = text
        if (current in videoServices)
            out += "\n\nVideo format: ${prefs.getString("aspect", "9:16")} aspect ratio, ${prefs.getInt("dur", 5)} seconds long."
        history.getOrPut(current) { mutableListOf() }.add(text)
        saveRecent(text)
        sendText(out)
        input.setText("")
    }

    private fun sendText(t: String) {
        web()?.evaluateJavascript("($SEND_JS)(${JSONObject.quote(t)})") { r ->
            if (r != null && r.contains("noinput")) toast("Wala makita ang chat box sa site. I-login una o i-tap ang chat box sa site.")
        }
    }

    private fun loadRecent(): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val a = JSONArray(prefs.getString("recent_$current", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) { }
        return out
    }

    private fun saveRecent(text: String) {
        val l = loadRecent()
        l.remove(text); l.add(0, text)
        val a = JSONArray()
        l.take(30).forEach { a.put(it) }
        prefs.edit().putString("recent_$current", a.toString()).apply()
    }

    private fun showRecent() {
        val l = loadRecent()
        if (l.isEmpty()) { toast("Wala pa'y recent prompts sa $current"); return }
        val items = Array(l.size) { val t = l[it].replace("\n", " "); if (t.length > 70) t.take(70) + "…" else t }
        AlertDialog.Builder(this).setTitle("Recent prompts · $current")
            .setItems(items) { _, i -> input.setText(l[i]); input.setSelection(input.text.length); input.requestFocus() }
            .setNegativeButton("Clear") { _, _ -> prefs.edit().remove("recent_$current").apply(); toast("Na-clear") }
            .setPositiveButton("Close", null).show()
    }

    private fun pickAccount() {
        val items = Array(count()) { "Account ${it + 1}" + if (it == idx()) "  ✓" else "" }
        AlertDialog.Builder(this).setTitle("$current accounts").setItems(items) { _, i ->
            prefs.edit().putInt("idx_$current", i).apply(); lastSwitch = System.currentTimeMillis(); show()
        }.show()
    }

    private fun addAccount() {
        prefs.edit().putInt("count_$current", count() + 1).putInt("idx_$current", count()).apply()
        lastSwitch = System.currentTimeMillis()
        show()
        toast("Bag-ong account: i-login na sa site")
    }

    private fun nextAccount(fromAuto: Boolean) {
        if (count() < 2) { toast("Pag-add una og lain nga account (＋ Account)"); return }
        prefs.edit().putInt("idx_$current", (idx() + 1) % count()).apply()
        lastSwitch = System.currentTimeMillis()
        val fresh = !views.containsKey(pname())
        show()
        if (fromAuto) toast("Limit na: gi-switch ngadto sa sunod nga account")
        val past = history[current]
        if (fromAuto && fresh && !past.isNullOrEmpty()) {
            val carry = "Padayon ta sa atong naunang topic. Mao ni ang akong gi-ingon kaniadto: " + past.takeLast(5).joinToString(" | ")
            h.postDelayed({ sendText(carry) }, 9000)
        }
    }

    private val watcher = object : Runnable {
        override fun run() {
            if (auto && System.currentTimeMillis() - lastSwitch > 30000) {
                web()?.evaluateJavascript("(document.body?document.body.innerText:'').toLowerCase().slice(-1500)") { r ->
                    if (r != null && limitWords.any { r.contains(it) }) nextAccount(true)
                }
            }
            h.postDelayed(this, 4000)
        }
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web()?.canGoBack() == true) web()?.goBack() else super.onBackPressed()
    }

    companion object {
        const val SEND_JS = """function(t){
 var el=document.querySelector('div[contenteditable="true"],textarea,[role="textbox"]');
 if(!el)return 'noinput';
 el.focus();
 if(el.tagName==='TEXTAREA'||el.tagName==='INPUT'){
  var d=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el),'value');
  d.set.call(el,t);
  el.dispatchEvent(new Event('input',{bubbles:true}));
 }else{
  document.execCommand('selectAll',false,null);
  document.execCommand('insertText',false,t);
 }
 setTimeout(function(){
  var b=document.querySelector('button[aria-label*="send" i],button[data-testid*="send" i],button[aria-label*="generate" i],button[type="submit"]');
  if(b&&!b.disabled){b.click();}
  else{['keydown','keypress','keyup'].forEach(function(n){el.dispatchEvent(new KeyboardEvent(n,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));});}
 },500);
 return 'ok';
}"""
        const val DL_JS = """function(){
 var vs=[].slice.call(document.querySelectorAll('video'));
 if(!vs.length){Steivy.msg('Walay video nga makita sa page');return;}
 var v=vs[vs.length-1];
 var src=v.currentSrc||v.src||(v.querySelector('source')||{}).src;
 if(!src){Steivy.msg('Walay video link');return;}
 if(src.indexOf('blob:')===0){
  fetch(src).then(function(r){return r.blob();}).then(function(b){
   var f=new FileReader();f.onload=function(){Steivy.saveVideo(f.result);};f.readAsDataURL(b);
  }).catch(function(e){Steivy.msg('Dili ma-download: '+e);});
 }else{Steivy.download(src);}
}"""
    }
}
